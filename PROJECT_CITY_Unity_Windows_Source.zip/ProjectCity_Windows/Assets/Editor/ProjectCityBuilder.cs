using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class ProjectCityBuilder
{
    [MenuItem("PROJECT CITY/Build Demo City Scene")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        RenderSettings.ambientLight = new Color(0.42f, 0.45f, 0.52f);
        RenderSettings.fog = true; RenderSettings.fogColor = new Color(0.48f, 0.53f, 0.62f); RenderSettings.fogMode = FogMode.Exponential; RenderSettings.fogDensity = 0.004f;
        Make("Ground", PrimitiveType.Plane, new Vector3(0,-0.12f,0), new Vector3(18,1,18), new Color(0.22f,0.28f,0.24f));
        Make("Main Road", PrimitiveType.Cube, new Vector3(0,0.01f,0), new Vector3(12,0.08f,180), new Color(0.12f,0.13f,0.15f));
        Make("Cross Road", PrimitiveType.Cube, new Vector3(0,0.02f,0), new Vector3(180,0.08f,12), new Color(0.12f,0.13f,0.15f));
        // Road lane dashes
        for (int z=-80; z<=80; z+=10) Make("Lane Mark", PrimitiveType.Cube, new Vector3(0,0.075f,z), new Vector3(0.22f,0.025f,4), new Color(0.9f,0.82f,0.53f));
        // City blocks around the central crossroad
        Color[] palette = { new Color(.30f,.34f,.39f), new Color(.42f,.37f,.32f), new Color(.28f,.34f,.37f), new Color(.46f,.43f,.37f), new Color(.31f,.30f,.35f) };
        for (int sideX=-1; sideX<=1; sideX+=2)
        for (int sideZ=-1; sideZ<=1; sideZ+=2)
        for (int i=0; i<5; i++)
        {
            float x=sideX*(17f+(i%2)*11f); float z=sideZ*(18f+i*23f);
            float h=Random.Range(10f,25f), w=Random.Range(9f,15f), d=Random.Range(10f,17f);
            var b=Make("Building", PrimitiveType.Cube,new Vector3(x,h/2,z),new Vector3(w,h,d),palette[Random.Range(0,palette.Length)]);
            // warm window strips on street-facing facade
            for(int floor=1; floor<h/3f; floor++)
            for(int win=0; win<3; win++)
            {
                var window=Make("Window",PrimitiveType.Cube,new Vector3(x-w/2f+1.5f+win*(w-3f)/3f,floor*2.5f,z-d/2f-0.06f),new Vector3(1.1f,1.1f,0.08f),new Color(0.9f,0.68f,0.32f));
                window.transform.SetParent(b.transform,true);
            }
        }
        // Street lamps
        for(int z=-70;z<=70;z+=20) { Lamp(new Vector3(-7,0,z)); Lamp(new Vector3(7,0,z)); }
        // Player
        var player=new GameObject("Player"); player.transform.position=new Vector3(2,1.1f,-5);
        var cc=player.AddComponent<CharacterController>(); cc.height=1.8f; cc.radius=.32f; cc.center=new Vector3(0,0,0);
        var camObj=new GameObject("Player Camera"); camObj.transform.SetParent(player.transform); camObj.transform.localPosition=new Vector3(0,.65f,0);
        var cam=camObj.AddComponent<Camera>(); cam.fieldOfView=78; cam.nearClipPlane=.08f; camObj.AddComponent<AudioListener>();
        var controller=player.AddComponent<ProjectCityController>(); controller.playerCamera=cam;
        // A simple drivable car
        var car=Make("City Car",PrimitiveType.Cube,new Vector3(4,.65f,-13),new Vector3(2.1f,1.1f,4.2f),new Color(.08f,.32f,.65f));
        car.AddComponent<BoxCollider>(); var carLogic=car.AddComponent<ProjectCityCar>();
        var anchor=new GameObject("Driving Camera Anchor"); anchor.transform.SetParent(car.transform); anchor.transform.localPosition=new Vector3(0,1.1f,-0.3f); anchor.transform.localRotation=Quaternion.identity; carLogic.cameraAnchor=anchor.transform;
        // Wheels
        foreach(float x in new float[]{-1.08f,1.08f}) foreach(float z in new float[]{-1.25f,1.25f}) { var wheel=Make("Wheel",PrimitiveType.Cylinder,car.transform.position+new Vector3(x,.0f,z),new Vector3(.38f,.22f,.38f),Color.black); wheel.transform.rotation=Quaternion.Euler(0,0,90); wheel.transform.SetParent(car.transform,true); }
        // Sun / moon-like warm light
        var sun=new GameObject("Sunset Directional Light"); sun.transform.rotation=Quaternion.Euler(38,-32,0); var light=sun.AddComponent<Light>(); light.type=LightType.Directional; light.intensity=1.15f; light.color=new Color(1f,.78f,.59f);
        // Skyline markers
        for(int i=0;i<12;i++) { float x=(i%2==0?-1:1)*Random.Range(48f,75f); float z=Random.Range(-85f,85f); float h=Random.Range(18f,48f); Make("Distant Skyline",PrimitiveType.Cube,new Vector3(x,h/2,z),new Vector3(Random.Range(7f,13f),h,Random.Range(8f,15f)),new Color(.24f,.27f,.32f)); }
        EditorSceneManager.SaveScene(scene,"Assets/ProjectCity_Demo.unity");
        Selection.activeGameObject=player;
        EditorUtility.DisplayDialog("PROJECT CITY","Готово! Сцена Assets/ProjectCity_Demo.unity создана. Нажми Play для запуска.","Отлично");
    }

    static GameObject Make(string name, PrimitiveType type, Vector3 pos, Vector3 scale, Color color)
    {
        var go=GameObject.CreatePrimitive(type); go.name=name; go.transform.position=pos; go.transform.localScale=scale;
        var renderer=go.GetComponent<Renderer>(); if(renderer){ var mat=new Material(Shader.Find("Standard")); mat.color=color; renderer.sharedMaterial=mat; }
        return go;
    }
    static void Lamp(Vector3 p)
    {
        Make("Lamp Post",PrimitiveType.Cylinder,p+new Vector3(0,2.3f,0),new Vector3(.08f,2.3f,.08f),new Color(.15f,.16f,.18f));
        var bulb=Make("Street Lamp",PrimitiveType.Sphere,p+new Vector3(0,4.5f,0),new Vector3(.35f,.35f,.35f),new Color(1f,.78f,.42f));
        var l=bulb.AddComponent<Light>(); l.type=LightType.Point; l.range=10; l.intensity=1.8f; l.color=new Color(1f,.68f,.36f);
    }
}
