using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class WindowsBuildMenu
{
    [MenuItem("PROJECT CITY/Build Windows EXE")]
    public static void BuildWindows()
    {
        // Generate the demo scene using the included scene builder.
        ProjectCityBuilder.Build();
        const string scenePath = "Assets/ProjectCity_Demo.unity";
        if (!File.Exists(scenePath))
        {
            EditorUtility.DisplayDialog("PROJECT CITY", "Сцена не создана. Сначала выбери PROJECT CITY → Build Demo City Scene.", "OK");
            return;
        }

        string outputDir = Path.GetFullPath("Build/Windows");
        Directory.CreateDirectory(outputDir);
        string exePath = Path.Combine(outputDir, "PROJECT_CITY.exe");
        var options = new BuildPlayerOptions
        {
            scenes = new[] { scenePath },
            locationPathName = exePath,
            target = BuildTarget.StandaloneWindows64,
            options = BuildOptions.None
        };
        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result == BuildResult.Succeeded)
            EditorUtility.DisplayDialog("PROJECT CITY", "Сборка готова:\n" + exePath, "Отлично");
        else
            EditorUtility.DisplayDialog("PROJECT CITY", "Сборка не завершилась. Подробности: Console в Unity.", "OK");
    }
}
