using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class ProjectCityController : MonoBehaviour
{
    public float walkSpeed = 5f;
    public float runSpeed = 8f;
    public float mouseSensitivity = 2f;
    public float jumpHeight = 1.2f;
    public float gravity = -20f;
    public Camera playerCamera;
    CharacterController controller;
    Vector3 velocity;
    float pitch;
    bool driving;
    ProjectCityCar activeCar;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        if (!playerCamera) playerCamera = GetComponentInChildren<Camera>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) { Cursor.lockState = CursorLockMode.None; Cursor.visible = true; }
        if (Input.GetMouseButtonDown(0)) { Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; }
        if (driving)
        {
            if (activeCar) activeCar.DriveInput(Input.GetAxis("Vertical"), Input.GetAxis("Horizontal"), Input.GetKey(KeyCode.Space));
            if (Input.GetKeyDown(KeyCode.E)) ExitCar();
            return;
        }
        LookAround();
        Move();
        if (Input.GetKeyDown(KeyCode.E)) TryEnterCar();
    }

    void LookAround()
    {
        float mx = Input.GetAxis("Mouse X") * mouseSensitivity;
        float my = Input.GetAxis("Mouse Y") * mouseSensitivity;
        transform.Rotate(Vector3.up * mx);
        pitch = Mathf.Clamp(pitch - my, -82f, 82f);
        if (playerCamera) playerCamera.transform.localRotation = Quaternion.Euler(pitch, 0, 0);
    }

    void Move()
    {
        float speed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed;
        Vector3 move = transform.right * Input.GetAxis("Horizontal") + transform.forward * Input.GetAxis("Vertical");
        controller.Move(move * speed * Time.deltaTime);
        if (controller.isGrounded && velocity.y < 0) velocity.y = -2f;
        if (controller.isGrounded && Input.GetKeyDown(KeyCode.Space)) velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }

    void TryEnterCar()
    {
        ProjectCityCar nearest = null;
        float best = 3.5f;
        foreach (var car in FindObjectsOfType<ProjectCityCar>())
        {
            float d = Vector3.Distance(transform.position, car.transform.position);
            if (d < best) { best = d; nearest = car; }
        }
        if (nearest) { activeCar = nearest; driving = true; controller.enabled = false; if (playerCamera) playerCamera.transform.SetParent(activeCar.cameraAnchor); playerCamera.transform.localPosition = Vector3.zero; playerCamera.transform.localRotation = Quaternion.identity; }
    }

    void ExitCar()
    {
        if (!activeCar) { driving = false; controller.enabled = true; return; }
        transform.position = activeCar.transform.position + activeCar.transform.right * 2.2f + Vector3.up * 0.2f;
        transform.rotation = Quaternion.Euler(0, activeCar.transform.eulerAngles.y, 0);
        if (playerCamera) { playerCamera.transform.SetParent(transform); playerCamera.transform.localPosition = new Vector3(0, 0.65f, 0); playerCamera.transform.localRotation = Quaternion.identity; }
        controller.enabled = true; driving = false; activeCar.StopCar(); activeCar = null; pitch = 0;
    }

    void OnGUI()
    {
        GUI.color = Color.white;
        GUI.Box(new Rect(16, 16, 270, driving ? 84 : 108), "PROJECT CITY  |  DEMO");
        GUI.Label(new Rect(28, 44, 250, 20), driving ? "WASD — ехать  |  SPACE — тормоз" : "WASD — движение  |  SHIFT — бег");
        GUI.Label(new Rect(28, 66, 250, 20), driving ? "E — выйти из машины" : "Мышь — обзор  |  SPACE — прыжок");
        if (!driving) GUI.Label(new Rect(28, 88, 250, 20), "E — сесть в ближайшую машину");
        GUI.Label(new Rect(Screen.width/2-5, Screen.height/2-8, 20, 20), "+");
    }
}
