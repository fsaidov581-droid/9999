using UnityEngine;

public class ProjectCityCar : MonoBehaviour
{
    public Transform cameraAnchor;
    public float acceleration = 12f;
    public float maxSpeed = 18f;
    public float turnSpeed = 65f;
    float speed;

    public void DriveInput(float throttle, float steering, bool brake)
    {
        if (brake) speed = Mathf.MoveTowards(speed, 0, 22f * Time.deltaTime);
        else speed = Mathf.MoveTowards(speed, throttle * maxSpeed, acceleration * Time.deltaTime);
        transform.Translate(Vector3.forward * speed * Time.deltaTime, Space.Self);
        if (Mathf.Abs(speed) > 0.5f) transform.Rotate(Vector3.up, steering * turnSpeed * Time.deltaTime * Mathf.Sign(speed));
    }
    public void StopCar() { speed = 0; }
}
